package planner.utility;

public class PublicVariable {
    public static final String MyPREFERENCES = "financialPrefs" ;
}
